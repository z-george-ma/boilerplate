"use strict";

var should = require("should");
/* global it */
/* global before */
/* global describe */

describe("1 + 1", function() {
  var actualOutput;

  before(function(done) {
    actualOutput = 1 + 1;
    done();
  });

  it("equals 2", function() {
	  should(actualOutput).eql(2);
  });
});

