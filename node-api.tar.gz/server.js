"use strict";

var config = require("config-node")();
var app = require("express")();

require("./api.js")(app);
require("./healthcheck.js")(app);

app.listen(config.port);
